<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/sucessodados.css">
    <title>Sucesso (FM)</title>
</head>
<body>
    <div id="cxprincipal">
    <h1>
    <?php
    if ($_POST["cxnome"] != "") {
        include_once "../factory/conexao.php";

        $nome = $_POST["cxnome"];
        $email = $_POST["cxemail"];
        $senha = $_POST["cxsenha"];
        $sql = "insert into tbusuario(nome,email,senha)
        values ('$nome','$email','$senha')";
        $query = mysqli_query($conn,$sql);
        echo "Dados cadastrados com sucesso!";
    } else {
        echo "Dados não cadastrados";
    }
    
?></h1>
<br>

<a href="/projetob/view/index.php" class="botao-voltar">Menu</a>
</div>

</body>
</html>