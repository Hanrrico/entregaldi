<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/sucessodados.css">
    <title>Sucesso (FM)</title>
</head>
<body>
    <div id="cxprincipal">
    <h1>
    <?php
    if ($_POST["cxempresa"] != "") {
        include_once "../factory/conexao.php";

        $empresa = $_POST["cxempresa"];
        $email = $_POST["cxemail"];
        $contato = $_POST["cxcontato"];
        $tel = $_POST["cxtel"];
        
        $sql = "insert into tbcomercio(empresa,email,contato,tel)
        values ('$empresa','$email','$contato','$tel')";
        $query = mysqli_query($conn,$sql);
        echo "Dados cadastrados com sucesso!";
    } else {
        echo "Dados não cadastrados";
    }
?></h1>
<br>

<a href="/projetob/view/index.php" class="botao-voltar">Menu</a>
</div>

</body>
</html>