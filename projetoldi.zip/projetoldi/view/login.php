<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/reset.css">
    <link rel="stylesheet" type="text/css" href="../css/main.css">
    <link rel="stylesheet" type="text/css" href="../css/formulario.css">
    <link rel="stylesheet" type="text/css" href="../css/login.css">
    <title>Login</title>
</head>
<body>
    
    <header>
        <div class="menu">
            <div class="menu_nav">
                
                <div class="menu_nav-left">

                </div>

                <div class="menu_nav-right">
                    <div class="menu_nav__link">
                        <a href="/projetob/view/index.php">Home</a>
                    </div>
                    <div class="menu_nav__link">
                        <a href="/projetob/view/login.php">Login</a>
                    </div>

                    <div class="menu_img">
                        <img src="../img/perfil.png" alt="">
                    </div>
                </div>
                
            </div>
        </div>
    </header>

    <main>
            <div id="cxprincipal">
                <figure id="cxfigura">
                        <img class="figura_icon" src="../img/perfil.png" alt="">        
                </figure>
                <div id="cxmenu">
                    <h1 class="texto">Acesso ao Sistema</h1>
                    <form action="" method="POST">
                        
                        <div class="container_form__itens">
    
                            <div class="container_form_itens__inputs">
                                
                                <div class="container_form_input">
                                    <label>Nome:</label><br/>
                                    <input type="name" name="cxname" class="cxname">
                                </div>
    
                                <div class="container_form_input">
                                    <label>E-mail:</label> <br/>
                                    <input type="e-mail" name="cxemail">
                                </div>
    
                                <div class="container_form_input">
                                    <label>Senha:</label> <br/>
                                    <input type="password" name="cxsenha" class="cxsenha">  
                                </div> 
    
                            </div>
    
                            <div class="container_form_itens__submit">    
                                <input type="submit" value="Acessar">
                            </div>
    
                        </div>
    
                    </form>
                </div>
            </div>
    </main>
    
    <footer>
        <div class="footer-content">
            <h3>CadastroUnido</h3>
            <p>Bem-vindo ao CadastroUnido! Somos uma plataforma dedicada a conectar amigos, facilitar o comércio e fornecer uma comunidade acolhedora para nossos usuários. Explore nossos recursos de cadastro de amigos, comércio e consulta de usuários para expandir sua rede e encontrar oportunidades emocionantes. Junte-se a nós hoje e faça parte desta vibrante comunidade online!</p>
            <ul class="socials">
                <li><a href="#"><i class="fa-brands fa-youtube"></i></a></li>
                <li><a href="#"><i class="fa-brands fa-linkedin"></i></a></li>
                <li><a href="https://github.com/Hanrrico"><i class="fa-brands fa-github"></i></a></li>
            </ul>
        </div>
        <div class="footer-bottom">
            <p>copyright &copy;2024 Pablo Henrique</p>
        </div>
    </footer>
</body>
</html>